# Custom Instruction Compiler

This compiler simulates the generation of assembly instructions from a simple arithmetic expression.

- **Name:** CUSTOM_ADDSUB
- **Inputs:** A, B, C
- **Output:** Z
- **Operation:** Z = A + B - C

## Usage

Compile the code:
    g++ compiler.cpp -o compiler

Run with input file:
    ./compiler input.txt

## Example
Input:
    a + b - c

    For A = 10, B = 5, C = 3  

Output:
    ADD a, b
    SUB a, c
The output will be: `Z = 12`

## Files

- `main.c`: C code simulating the instruction
- `README.md`: Project documentation

## How to Run

```bash
gcc main.c -o run
./run