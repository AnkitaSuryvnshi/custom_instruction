
# Custom Instruction Compiler

This compiler simulates the generation of assembly instructions from a simple arithmetic expression.

## Usage

Compile the code:
    g++ compiler.cpp -o compiler

Run with input file:
    ./compiler input.txt

## Example
Input:
    a + b - c

Output:
    ADD a, b
    SUB a, c
